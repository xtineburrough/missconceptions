## Contributing

You are free to do whatever you like!
- Add new features
- Improve current code
- Resolve issues
- Forks & pull requests

Whatever you see fit basically as long as it doesn't break the main purpose of the plugin, namely - the parallax effect :blush:
